#!/bin/bash

# Instalasi paket-paket yang diperlukan
apt-cdrom add
apt install -y apache2 libapache2-mod-php7.0 php7.0 php7.0-snmp php7.0-xml php7.0-mbstring php7.0-json php7.0-gd php7.0-gmp php7.0-zip php7.0-ldap php7.0-mcrypt mariadb-server mariadb-client snmp snmpd

# Unduh dan ekstrak Cacti
tar xfz cacti-1.2.27.tar.gz
mv cacti-* /var/www/html/cacti
cd /var/www/html/cacti

# Konfigurasi database
sudo mysql -u root -p <<EOF
CREATE DATABASE cacti;
CREATE USER 'cactiuser'@'localhost' identified by 'cactiuser';
GRANT ALL PRIVILEGES ON cacti.* TO 'cactiuser'@'localhost' IDENTIFIED BY 'cactiuser';
FLUSH PRIVILEGES;
EXIT;
EOF
sudo mysql -u cactiuser -p cacti < /var/www/html/cacti/cacti.sql

# Konfigurasi SNMP
echo "rocommunity public" | sudo tee -a /etc/snmp/snmpd.conf
sudo systemctl restart snmpd

# Akses Cacti melalui web
echo "Selesai! Buka browser dan akses http://<IP_server>/cacti untuk melanjutkan konfigurasi."
