#!/bin/bash

# Fungsi untuk mendapatkan versi PHP
get_php_version() {
    php -r 'echo PHP_VERSION;' | cut -d '.' -f 1,2
}

# Instalasi paket-paket yang diperlukan
sudo apt update
sudo apt install -y apache2 libapache2-mod-php7.0 php7.0 php7.0-snmp php7.0-xml php7.0-mbstring php7.0-json php7.0-gd php7.0-gmp php7.0-zip php7.0-ldap php7.0-mcrypt mariadb-server mariadb-client snmp snmpd

# Dapatkan versi PHP yang terinstal
PHP_VERSION=$(get_php_version)

# Tentukan lokasi file php.ini untuk Apache
PHP_INI="/etc/php/$PHP_VERSION/apache2/php.ini"

# Lokasi file konfigurasi MariaDB
MARIADB_CONF="/etc/mysql/mariadb.conf.d/50-server.cnf"

# Pengaturan PHP yang ingin ditambahkan atau dimodifikasi
TIMEZONE="date.timezone = US/Central"
MEMORY_LIMIT="memory_limit = 512M"
MAX_EXECUTION_TIME="max_execution_time = 60"

# Pengaturan MariaDB yang ingin ditambahkan atau dimodifikasi
MARIADB_SETTINGS=(
    "collation-server = utf8mb4_unicode_ci"
    "character-set-server = utf8mb4"
    "max_heap_table_size = 128M"
    "tmp_table_size = 64M"
    "join_buffer_size = 64M"
    "innodb_file_format = Barracuda"
    "innodb_large_prefix = 1"
    "innodb_buffer_pool_size = 1G"
    "innodb_buffer_pool_instances = 10"
    "innodb_flush_log_at_timeout = 3"
    "innodb_read_io_threads = 32"
    "innodb_write_io_threads = 16"
    "innodb_io_capacity = 5000"
    "innodb_io_capacity_max = 10000"
)

# Fungsi untuk menambahkan atau memperbarui pengaturan di file konfigurasi
update_config() {
    local setting=$1
    local file=$2

    if grep -q "^${setting%%=*}" "$file"; then
        sudo sed -i "s|^${setting%%=*}.*|$setting|" "$file"
    else
        echo "$setting" | sudo tee -a "$file" > /dev/null
    fi
}

# Pastikan file php.ini ada
if [ -f "$PHP_INI" ]; then
    # Update php.ini dengan pengaturan yang diinginkan
    update_config "$TIMEZONE" "$PHP_INI"
    update_config "$MEMORY_LIMIT" "$PHP_INI"
    update_config "$MAX_EXECUTION_TIME" "$PHP_INI"
else
    echo "File $PHP_INI tidak ditemukan."
    exit 1
fi

# Pastikan file 50-server.cnf ada
if [ -f "$MARIADB_CONF" ]; then
    # Update 50-server.cnf dengan pengaturan yang diinginkan
    for setting in "${MARIADB_SETTINGS[@]}"; do
        update_config "$setting" "$MARIADB_CONF"
    done
else
    echo "File $MARIADB_CONF tidak ditemukan."
    exit 1
fi

# Restart MariaDB untuk menerapkan perubahan
sudo systemctl restart mariadb

# Nonaktifkan versi PHP saat ini (jika perlu)
sudo a2dismod php*

# Aktifkan versi PHP yang diinginkan
sudo a2enmod php$PHP_VERSION

# Restart Apache untuk menerapkan perubahan
sudo systemctl restart apache2

# Update alternatif PHP untuk CLI
sudo update-alternatives --set php /usr/bin/php$PHP_VERSION

# Unduh dan ekstrak Cacti
wget https://www.cacti.net/downloads/cacti-1.2.27.tar.gz
tar xfz cacti-1.2.27.tar.gz
sudo mv cacti-1.2.27 /var/www/html/cacti
cd /var/www/html/cacti

# Konfigurasi database
sudo mysql -u root -p <<EOF
CREATE DATABASE cacti;
CREATE USER 'cactiuser'@'localhost' identified by 'cactiuser';
GRANT ALL PRIVILEGES ON cacti.* TO 'cactiuser'@'localhost' IDENTIFIED BY 'cactiuser';
FLUSH PRIVILEGES;
EXIT;
EOF
sudo mysql -u cactiuser -p cacti < /var/www/html/cacti/cacti.sql

# Konfigurasi SNMP
echo "rocommunity public" | sudo tee -a /etc/snmp/snmpd.conf
sudo systemctl restart snmpd

# Akses Cacti melalui web
echo "Selesai! Buka browser dan akses http://<IP_server>/cacti untuk melanjutkan konfigurasi."